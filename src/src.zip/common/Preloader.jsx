import React from 'react';
import preloader from "../images/loader.svg";

const Preloader = (props) => {
    return (
        <>
           <img src={preloader}/>
        </>
    )
}

export default Preloader;