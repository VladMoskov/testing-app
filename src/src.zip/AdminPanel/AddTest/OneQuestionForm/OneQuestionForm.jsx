import s from '../AddTest.module.css';
import {Field, Form} from "react-final-form";
import {setNewTest} from "../../../Redux/add-test-reducer";
import React from "react";

const OneQuestionForm = (props) => {

    let onSubmit = (formData) => {
        setNewTest(formData);
        console.log(formData);
    }

    return (
        <div>
            <div className={s.wrapper}>
                <Form onSubmit={onSubmit}>
                    {props => (
                        <form onSubmit={props.handleSubmit}>
                            <label>first question</label>
                            <div>
                                <Field name='firstQ' component='textarea'/>
                            </div>
                            <button type="submit">Submit</button>
                        </form>
                    )}
                </Form>
            </div>
        </div>
    )
}

export default OneQuestionForm;