import React from 'react';
import s from './Footer.module.css';

const Footer = (props) => {
    return (
        <div>
            <div className={s.wrapper}>

            </div>
        </div>
    )
}

export default Footer;