import {testsAPI} from "../API/API";

const ADD_TEST = 'addTest/ADD_TEST';

let initialState = {
    tests: [{
        questions: [
            { question: null, answers: [] }
        ],
        date: null
    }]
}

const addTestReducer = (state = initialState, action) => {

    switch (action.type) {

        case ADD_TEST: {
            return {
                ...state,
                tests: [...state.tests, action.test],
                date: new Date()
            }
        }

        default:
            return state;
    }
}

export const setNewTest = (test) => ({type: ADD_TEST, test});

export default addTestReducer;