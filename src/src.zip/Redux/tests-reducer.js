import {testsAPI} from "../API/API";

const GET_TESTS = 'testsPage/GET_TESTS';
const IS_FETCHING = 'testsPage/IS_FETCHING_TOGGLE';

let initialState = {
    tests: [
        {
            id: 0,
            name: 'name',
            description: 'description',
        },
    ],
    isFetching: false
}

const testsReducer = (state = initialState, action) => {

    switch (action.type) {
        case GET_TESTS:
            return {
                ...state,
                tests: [...action.tests]
            }

        case IS_FETCHING:
            return {
                ...state,
                isFetching: !state.isFetching
            }

        default:
            return state;
    }
}

export const setTests = (tests) => ({type: GET_TESTS, tests});
export const isFetchingToggle = () => ({type: IS_FETCHING})

export const getTests = () => (dispatch) => {
    testsAPI.getTests()
        .then(res => dispatch(setTests(res.data)))
}

export default testsReducer;