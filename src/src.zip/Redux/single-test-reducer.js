import {testsAPI} from "../API/API";

const SET_TEST = 'GET_TEST';
const SET_IS_FETCHING = 'SET_IS_FETCHING';

let initialState = {
    id: 0,
    name: 'name',
    questions: [],
    description: 'description',
    answers: [
        {
            string: '',
            bool: false,
        }
    ],
    isFetching: false
}

const singleTestReducer = (state = initialState, action) => {

    switch (action.type) {

        case SET_TEST:
            return {
                ...state,
                ...action.test
            }

        case SET_IS_FETCHING:
            return {
                ...state,
                isFetching: !state.isFetching
            }

        default:
            return state;
    }
}

const setTest = (test) => ({type: SET_TEST, test});
const setIsFetching = () => ({type: SET_IS_FETCHING});

export const getTest = (testId) => (dispatch) => {
    dispatch(setIsFetching());
    testsAPI.getTest(testId)
        .then(res => {
            dispatch(setTest(res.data));
            dispatch(setIsFetching());
        })
}

export default singleTestReducer;