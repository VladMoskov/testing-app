import React from 'react';
import s from './Content.module.css';

const Content = (props) => {
    return (
        <div>
            <div className={s.wrapper}>

            </div>
        </div>
    )
}

export default Content;