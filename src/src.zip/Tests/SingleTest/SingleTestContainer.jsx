import React, {useEffect} from 'react';
import {connect} from "react-redux";
import {getTest} from "../../Redux/single-test-reducer";
import Preloader from "../../common/Preloader";

let SingleTest = (props) => {

    useEffect(() => {
        props.getTest(props.id);
    }, [])


    if (props.testData.isFetching) {
        return <div><Preloader /></div>
    } else {
        return (
            <div>
                <div>
                    <h1>{props.testData.id}</h1>
                </div>
                <div>
                    <h1>{props.testData.name}</h1>
                </div>
                <div>
                    <h1>{props.testData.description}</h1>
                </div>

            </div>
        )
    }
}

let mapStateToProps = (state) => {
    return {
        testData: state.singleTestPage,
    }
}

export const SingleTestContainer = connect(mapStateToProps, {getTest})(SingleTest);