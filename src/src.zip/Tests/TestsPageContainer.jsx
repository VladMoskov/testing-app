import React, {useEffect} from 'react';
import {connect} from "react-redux";
import {getTests, isFetchingToggle} from "../Redux/tests-reducer";
import TestItem from "./TestItem/TestItem";
import {withRouter} from "react-router-dom";
import {SingleTestContainer} from "./SingleTest/SingleTestContainer";
import Preloader from "../common/Preloader";

const TestsPage = (props) => {

    let testId = props.match.params.testId;

    useEffect(() => {
        props.getTests();
    }, [])

    let tests = props.tests.map(test =>
        <TestItem id={test.id} name={test.name} description={test.description}/>
    )
    if (!props.isFetching) {
        return (
            <div>
                {!testId ? tests : <SingleTestContainer id={testId}/>}
            </div>
        )
    } else {
        return (
            <div>
                <Preloader/>
            </div>
        )
    }
}

let mapStateToProps = (state) => {
    return {
        tests: state.testsPage.tests,
        isFetching: state.testsPage.isFetching,
    }
}

export const TestsPageContainer = connect(mapStateToProps, {isFetchingToggle, getTests})(withRouter((TestsPage)));